from graybox.exceptions.not_a_function_error import NotAFunctionError
from graybox.tools.delete_file import delete_file
from graybox.tools.generate_module import generate_module
from graybox.tools.generate_solution_file import generate_solution_file

status = ['PASSED', 'FAILED', 'EXECUTION_ERROR', 'FUNCTION_NOT_FOUND', 'NOT_A_FUNCTION']


def evaluate_gray_box(solution, function_name, args, expected):
    result = ''

    name = generate_solution_file(solution)

    try:
        module = generate_module(name)

        function = getattr(module, function_name)

        if not callable(function):
            raise NotAFunctionError(function_name)

        actual = function(*args)

        result = status[0] if expected == actual else status[1]

        return {
            'status': result,
            'expected': expected,
            'got': actual
        }

    except AttributeError:
        return {
            'status': status[3],
            'details': f'{function_name} function is not on the solution'
        }

    except NotAFunctionError as error1:

        return {
            'status': status[4],
            'details': error1.message
        }

    except Exception as error:
        raise error

    finally:
        delete_file(name)
